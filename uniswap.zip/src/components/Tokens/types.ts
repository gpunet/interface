export enum Category {
  percentChange = 'Change',
  marketCap = 'Market Cap',
  price = 'Price',
  volume = 'Volume',
}
export enum SortDirection {
  increasing = 'Increasing',
  decreasing = 'Decreasing',
}
