export const MAXNUM = 5 // INFINITE if don't setting
